// Copyright (c) 2017 GeometryFactory, Sophia Antipolis (France)
//  All rights reserved.
//
// This file is part of CGAL (www.cgal.org)
//
// $URL: https://github.com/CGAL/cgal/blob/releases/CGAL-5.0/Installation/include/CGAL/stddef.h $
// $Id: stddef.h 52164b1 2019-10-19T15:34:59+02:00 Sébastien Loriot
// SPDX-License-Identifier: LGPL-3.0-or-later OR LicenseRef-Commercial

#error You have added .../path/to/CGAL-x.y/include/CGAL to the INCLUDE path. You should use .../path/to/CGAL-x.y/include instead.
